create view CAPITALIZES_EMAIL as
select email as email_new from employees
/

