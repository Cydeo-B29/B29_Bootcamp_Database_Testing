create view FULLNAMETABLE as
select  FIRST_NAME || ' '|| LAST_NAME as fullName from EMPLOYEES
/

