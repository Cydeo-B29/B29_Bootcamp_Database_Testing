create view CAPTILIZED_EMAIL_ZEK as
select email,initcap(email) as email_new_zek from Employees
/

