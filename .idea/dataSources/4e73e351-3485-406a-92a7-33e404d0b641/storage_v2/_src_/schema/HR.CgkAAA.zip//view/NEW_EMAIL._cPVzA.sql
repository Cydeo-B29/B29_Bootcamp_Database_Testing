create view NEW_EMAIL as
select EMAIL , initcap(EMAIL) as email_new from EMPLOYEES
/

