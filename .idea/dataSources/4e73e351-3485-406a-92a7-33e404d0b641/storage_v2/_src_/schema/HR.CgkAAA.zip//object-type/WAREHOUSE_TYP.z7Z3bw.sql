create TYPE WAREHOUSE_TYP 
    AS OBJECT 
    ( 
        WAREHOUSE_ID NUMBER (3) , 
        WAREHOUSE_NAME VARCHAR2 (35) , 
        LOCATION_ID NUMBER (4) 
    ) FINAL 
;
/

