create view CAPTILIZE_EMAIL as
select email,initcap(EMAIL) as email_new from EMPLOYEES
/

