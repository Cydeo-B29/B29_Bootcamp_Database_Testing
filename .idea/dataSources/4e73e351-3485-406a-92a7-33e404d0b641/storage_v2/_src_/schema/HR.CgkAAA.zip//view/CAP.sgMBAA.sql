create view CAP as
select email , initcap(email) as CAP from EMPLOYEES
/

