create view CAPTILIZEDZEK_EMAIL as
select email,initcap(email) as email_new_zek from Employees
/

