create view FULLNAME as
select FIRST_NAME ||' '|| upper(LAST_NAME) as fullname from EMPLOYEES
/

