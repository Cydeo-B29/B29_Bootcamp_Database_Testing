create view CAPTILIZED_EMAILS46 as
select email,initcap(email) as email_new from Employees
/

