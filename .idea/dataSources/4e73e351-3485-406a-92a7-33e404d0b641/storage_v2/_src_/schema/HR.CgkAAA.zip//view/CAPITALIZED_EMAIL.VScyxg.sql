create view CAPITALIZED_EMAIL as
select email, initcap(email) as email_new from EMPLOYEES
/

