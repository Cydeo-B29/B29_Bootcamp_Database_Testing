create view CAPITALIZEDEMAIL as
select  EMAIL, initcap(email) as email_new from EMPLOYEES
/

