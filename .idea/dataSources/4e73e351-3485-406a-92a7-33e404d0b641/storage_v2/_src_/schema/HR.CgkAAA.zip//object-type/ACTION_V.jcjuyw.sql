create TYPE ACTION_V 
    IS VARRAY ( 4 ) OF UNKNOWN 
;
/

