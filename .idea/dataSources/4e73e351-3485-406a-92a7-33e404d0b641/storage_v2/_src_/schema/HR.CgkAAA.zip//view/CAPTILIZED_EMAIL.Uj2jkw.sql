create view CAPTILIZED_EMAIL as
select email,initcap(email) as email_new from EMPLOYEES
/

