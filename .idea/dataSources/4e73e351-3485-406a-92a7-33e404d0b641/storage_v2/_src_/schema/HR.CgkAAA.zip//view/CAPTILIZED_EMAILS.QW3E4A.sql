create view CAPTILIZED_EMAILS as
select email,initcap(email) as email_zek from Employees
/

